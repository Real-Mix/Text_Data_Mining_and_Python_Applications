import jieba
f_path=r'D:\Python3sy\exercise\ex2-3\1.txt'
with open(f_path) as f:
   contents=f.read()
   seg_list = jieba.cut(contents,cut_all=False)
   print('/'.join(seg_list))


